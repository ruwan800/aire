#ifndef BAYESCLASSIFIER_H_
#define BAYESCLASSIFIER_H_

class BayesClassifier {
public:
	static int takeDecision(int regOne, int regTwo, int regThree,
			int regFour, int regFive, int regSix);
};
#endif
